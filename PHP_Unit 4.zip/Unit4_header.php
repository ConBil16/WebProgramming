<header>
    <h1> Connor's Exotic Goods <br> <i>Your one stop shop</i> </h1>
    <ul>
    <li> <a href="Unit4_store.php">Store</a> </li>
    <li> <a href="Unit4_order_entry.php">Order Entry</a> </li>
    <li> <a href="Unit4_adminProduct.php">Products</a></li>
    <li> <a id="admin" href="Unit4_admin.php">Admin</a> </li>
    </ul>
</header>
    