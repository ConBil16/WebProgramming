<?php 
    $servername = "localhost";
    $username = "cbilgrave"; 
    $password = "!a2Ph(JE]vlL4f4@";
    $dbname = "cbilgrave";
?>