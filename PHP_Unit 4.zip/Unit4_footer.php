<footer>
    <p> <b> The greatest goods for the distinguished citizens </b> <br> Feel free to tell us how we did <a href='mailto:someone@yoursite.com'>here</a> </p>
</footer>